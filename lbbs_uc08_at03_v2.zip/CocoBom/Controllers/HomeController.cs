﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CocoBom.Models;

namespace CocoBom.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Quem_Somos()
        {
            return View();
        }

        public IActionResult Produtos()
        {
            return View();
        }

        public IActionResult Fale_conosco()
        {
            return View();
        }

        public IActionResult Loja()
        {
            return View();
        }

        public IActionResult Descricao(int id)
        {
            switch (id)
            {
                case 12501:
                    ViewBag.titulo = "Amendoim";
                    ViewBag.sabor = "Bala recheada sabor amendoim";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado e amendoim.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/amendoim.jpeg";
                    break;
                case 12502:
                    ViewBag.titulo = "Beijinho";
                    ViewBag.sabor = "Bala recheada sabor beijinho";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado e coco ralado.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/beijinho.jpeg";
                    break;
                case 12503:
                    ViewBag.titulo = "Cereja";
                    ViewBag.sabor = "Bala recheada sabor cereja";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado, fruta e corante.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/amendoim.jpeg";
                    break;
                case 12504:
                    ViewBag.titulo = "Coco Queimado";
                    ViewBag.sabor = "Bala recheada sabor coco queimado";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado e coco ralado torrado.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/coco-queimado.jpeg";
                    break;
                case 12505:
                    ViewBag.titulo = "Coco Tradicional";
                    ViewBag.sabor = "Bala de coco sem recheio";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/coco-tradicional.jpeg";
                    break;
                case 12506:
                    ViewBag.titulo = "Gengibre";
                    ViewBag.sabor = "Bala recheada sabor gengibre";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado e gengibre desidratado.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/gengibre.jpeg";
                    break;
                case 12507:
                    ViewBag.titulo = "Leite Ninho";
                    ViewBag.sabor = "Bala recheada sabor leite ninho";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado e leite em pó integral.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/leite-ninho.jpeg";
                    break;
                case 12508:
                    ViewBag.titulo = "Maracujá";
                    ViewBag.sabor = "Bala recheada sabor maracujá";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado e maracujá desidratado.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/maracuja.jpeg";
                    break;
                case 12509:
                    ViewBag.titulo = "Morango";
                    ViewBag.sabor = "Bala recheada sabor morango";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado e nesquick.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/morango.jpeg";
                    break;
                case 12510:
                    ViewBag.titulo = "Nozes";
                    ViewBag.sabor = "Bala recheada sabor nozes";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado e nozes.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/nozes.jpeg";
                    break;
                case 12511:
                    ViewBag.titulo = "Nutella";
                    ViewBag.sabor = "Bala recheada sabor nutella";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado, creme de leite e nutella.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/nutella.jpeg";
                    break;
                case 12512:
                    ViewBag.titulo = "Prestígio";
                    ViewBag.sabor = "Bala recheada sabor prestígio";
                    ViewBag.ingredientes = "Ingredientes: água, açúcar, leite de coco, leite condensado, chocolate em pó e coco ralado.";
                    ViewBag.preco = "Preço: R$ 10,00";
                    ViewBag.imagem = "~/imagens/prestigio.jpeg";
                    break;
                default:
                    ViewBag.titulo = "Sabor não definido";
                    ViewBag.sabor = "";
                    ViewBag.ingredientes = "";
                    ViewBag.preco = "";
                    ViewBag.imagem = "~/imagens/no-photo-240-0.png";
                    break;
            }
            return View();
        }

        public IActionResult Cadastro(string nome, string email, string mensagem)
        {
            ViewData["Nome"] = "Nome: " + nome;
            ViewData["email"] = "email: " + email;
            ViewData["Mensagem"] = "Mensagem: " + mensagem;
            return View("Cadastro");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
